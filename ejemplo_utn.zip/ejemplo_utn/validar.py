import re


class Validar:
    def __init__(
        self,
    ):
        print("validar")

    def regex_nombre(self, avalidar):
        print(avalidar)
        reg = "nombre"
        return reg

    def regex_descripcion(self, avalidar):
        print(avalidar)
        reg = "descripcion"
        return reg

    def regex_fecha(self, avalidar):
        print(avalidar)
        reg = "fecha"
        return reg